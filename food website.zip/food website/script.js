//Login Function
function validateLogin() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(email)) {
        alert("Invalid email format");
        return false;
    }

    if (password.length < 8) {
        alert("Password must be at least 8 characters long");
        return false;
    }
    return true;
}
let captchaCode = '';

function generateCaptcha() {
    const canvas = document.getElementById('captchaCanvas');
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    captchaCode = Math.random().toString(36).substring(2, 8);
    ctx.font = '24px Arial';
    ctx.fillStyle = '#000';
    ctx.fillText(captchaCode, 10, 30);
}

document.addEventListener('DOMContentLoaded', () => {
    generateCaptcha();

    document.getElementById('Login').addEventListener('submit', function(e) {
        const input = document.getElementById('captchaInput').value;
        if (input !== captchaCode) {
            e.preventDefault();
            document.getElementById('error-message').textContent = 'Captcha incorrect. Please try again.';
            generateCaptcha();
        }
    });
});
//Login Form Validation
document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("Login");
    const content = document.getElementById("content");
    const loginSection = document.getElementById("Login");
    const emailField = document.getElementById("email");
    const passwordField = document.getElementById("password");
    const errorMessage = document.getElementById("error-message");

    // Dummy user credentials
    const validEmail = "admin@example.com";
    const validPassword = "password123";

   

    // Check if user is already logged in
    if (localStorage.getItem("loggedIn") === "true") {
        loginSection.style.display = "none";
        content.style.display = "block";
        showLogoutButton(); // Show logout button immediately
    }

    // Login form event listener
    loginForm.addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent form submission

        const email = emailField.value;
        const password = passwordField.value;

        // Check credentials
        if (email === validEmail && password === validPassword) {
            localStorage.setItem("loggedIn", "true"); // Store login state
            loginSection.style.display = "none";
            content.style.display = "block";
            showLogoutButton(); // Show logout button immediately after login
        } else {
            errorMessage.textContent = "Invalid login credentials!";
            errorMessage.style.color = "red";
        }
    });
});
//cart add
document.addEventListener("DOMContentLoaded", () => {
    let cartCount = 0;
    const cartCountDisplay = document.getElementById("cart-count");
    const addToCartButtons = document.querySelectorAll(".add-to-cart");

    addToCartButtons.forEach(button => {
        button.addEventListener("click", () => {
            cartCount++;
            cartCountDisplay.textContent = cartCount;
        });
    });
});

//Delivery section
document.addEventListener("DOMContentLoaded", () => {
    let cartCount = 0;
    const cartCountDisplay = document.getElementById("cart-count");
    const addToCartButtons = document.querySelectorAll(".add-to-cart");

    addToCartButtons.forEach(button => {
        button.addEventListener("click", () => {
            cartCount++;
            cartCountDisplay.textContent = cartCount;
        });
    });

    document.getElementById("delivery-form").addEventListener("submit", function (event) {
        event.preventDefault();
        alert("Order placed successfully!");
        this.reset();
    });
});

// Contact Form Validation
document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("contact-form").addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent form from reloading the page

        let name = document.getElementById("contact-name").value.trim();
        let email = document.getElementById("contact-email").value.trim();
        let message = document.getElementById("contact-message").value.trim();

        if (name !== "" && email !== "" && message !== "") {
            alert("Message sent successfully!"); // Display success message
            this.reset(); // Clear the form
        } else {
            alert("Please fill in all fields."); // Show validation message
        }
    });
});
 // Logout button setup
 const logoutButton = document.createElement("button");
 logoutButton.textContent = "Logout";
 logoutButton.style.margin = "20px";
 logoutButton.style.padding = "10px";
 logoutButton.style.cursor = "pointer";
 logoutButton.addEventListener("click", function () {
     localStorage.removeItem("loggedIn");
     location.reload(); // Refresh the page to reset state
 });

 // Function to show logout button
 function showLogoutButton() {
     if (!document.body.contains(logoutButton)) {
         document.body.appendChild(logoutButton);
     }
 }




